<?php

class ctrPlantilla{

	public function ctrEjecutarPlantilla()
	{
		include_once "vistas/plantilla.php";
	}

}