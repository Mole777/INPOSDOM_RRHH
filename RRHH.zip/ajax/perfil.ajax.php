<?php

	require_once "../controladores/perfil.controlador.php";
	require_once "../modelos/perfil.modelo.php";

	class ajaxPerfil{

		public $idPerfil;

		public function ajaxMostrarPerfil()
		{
			$campo = "";
		}


	}

