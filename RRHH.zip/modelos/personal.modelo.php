<?php

require_once "conexion.php";

class mdlPersonal{

	static public function mdlCrearPersonal()
	{

	}
	
}