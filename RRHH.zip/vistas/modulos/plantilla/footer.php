<footer class="main-footer">
	<strong>Copyright &copy; <?= date("Y"); ?>.</strong> Desarrollado por Génesis M. Sarante Feliz
</footer>