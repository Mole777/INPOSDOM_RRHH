<footer class="main-footer">
	<strong>Copyright &copy; <?= date("Y"); ?>.</strong> Todos los derechos reservados
</footer>