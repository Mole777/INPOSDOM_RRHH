<div class="content-wrapper">

  <section class="content-header">

    <div class="container-fluid">

      <div class="row">

        <div class="col-sm-6">

          <h1>Perfil</h1>

        </div>

        <div class="col-sm-6">

          <ol class="breadcrumb float-sm-right">

            <li class="breadcrumb-item"><a href="#">Perfil</a></li>

            <li class="breadcrumb-item active">Inicio</li>

          </ol>

        </div>

      </div>

    </div>

  </section>

  <section class="content">

    <div class="card card-outline card-primary"> 

      <div class="card-body">

        <div class="container-fluid">

          <div class="row">
            
          </div>
      
        </div>

      </div>

    </div>         

  </section>

</div>